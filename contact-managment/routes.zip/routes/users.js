const express = require("express");
const router = express.Router();
const User = require("../models/User");
const { validationResult } = require("express-validator");

//@route POST api/users
//@describe Register a new User
//@access public

router.post(
  '/',
  [ 
    check('name','Please enter a name').not().isEmpty(),
    check('email','Please enter a valid email').not().isEmpty(),
    check('password','Please enter atleast 6 letters').not().isLength(),
    min:6,
  }),
],
 async (req, res), => {
  const result=validationResult(req);

  if(!result.isEmpty(){
    return res.status(400).json({errors:SpeechRecognitionResultList.array() })
  }
  const {name,email,password}=req.body;

    try{
      let users= await User.findOne({email}):

      if (user) {
        
      }
    }
module.exports = router;
